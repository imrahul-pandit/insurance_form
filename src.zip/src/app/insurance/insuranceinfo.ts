export class Insuranceinfo {

    constructor(
        
       
          public name: string,
          public state: string,
          public invoice: string,
          public invoicedevice: string,
          public mobile: string,
          public emailid: string,
          public category: string,
          public datepurchase: string,
          public brand: string,
          public devicemodel: string,
          public inumber1: string,
          public imei_two: string,
          public insurance: string,
          public planid: string,
          public serialno: string,
          public policetype: string,
          public programtype: string,
          public planbought: string,
          public declared: string,
          public startdate: string,
          public endtdate: string,
          public premiumrate: string,
          public premiumend: string,
          public tax: string,
          public premiuminc: string,
          public premiumiat: string,
          public mrp: string,
        
  
        ) {  }

}
